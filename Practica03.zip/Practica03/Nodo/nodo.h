#ifndef __NODO_H__
#define __NODO_H__

#include <stdio.h>

struct nodo{
    int valor;
};

typedef struct nodo Nodo;

Nodo *crearNodo(int Valor);

int obtenerValor(const Nodo *);

void asignarValor(Nodo *,  int);

void destruirNodo(Nodo *);

#endif